import android.graphics.Color
import mx.edu.ittepic.ladm_p1_floresmedrano.MainActivity

class Hilo (p:MainActivity):Thread(){
    var puntero = p

    override fun run() {
        super.run()
        sleep(2000)
        while(true){
            sleep(10)
            puntero.runOnUiThread {
                puntero.lienzo!!.animarCirculo()
            }
        }
    }
}