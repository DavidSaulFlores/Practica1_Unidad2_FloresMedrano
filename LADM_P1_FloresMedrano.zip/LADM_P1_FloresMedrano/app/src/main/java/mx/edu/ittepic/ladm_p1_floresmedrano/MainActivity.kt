package mx.edu.ittepic.ladm_p1_floresmedrano

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import Hilo

class MainActivity : AppCompatActivity() {
    var lienzo  : Lienzo ?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lienzo=Lienzo(this)
        setContentView(lienzo!!)
        Hilo(this).start()
    }
}
