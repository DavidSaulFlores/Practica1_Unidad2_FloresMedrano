package mx.edu.ittepic.ladm_p1_floresmedrano

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

class PocosNieve () {
    var x = 0f
    var y = 0f
    var radio = 0f
    var incY = 5

    constructor(x: Int, y: Int, radio: Int) : this() {
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.radio = radio.toFloat()
    }
    fun pintar(c: Canvas, p: Paint){
        p.color=Color.WHITE
        c.drawCircle(x,y,radio,p)
    }
    fun balanceo(ancho:Int, alto:Int){
        y+= incY
        if(y>=alto){
            y = -50f
        }
    }



}