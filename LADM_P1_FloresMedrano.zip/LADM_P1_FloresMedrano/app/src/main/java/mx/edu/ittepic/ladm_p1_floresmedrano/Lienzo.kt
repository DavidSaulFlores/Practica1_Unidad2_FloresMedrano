package mx.edu.ittepic.ladm_p1_floresmedrano

import android.graphics.*
import android.graphics.Path.FillType
import android.view.View


class Lienzo(p:MainActivity): View(p) {
    var circulo0 = PocosNieve(20, -250, 15)
    var circulo1 = PocosNieve(100, -300, 15)
    var circulo2 = PocosNieve(160, -100, 15)
    var circulo3 = PocosNieve(270, -30, 15)
    var circulo4 = PocosNieve(450, -350, 15)
    var circulo5 = PocosNieve(120, -150, 15)
    var circulo6 = PocosNieve(150, -400, 15)
    var circulo7 = PocosNieve(200, -150, 15)
    var circulo8 = PocosNieve(230, -450, 15)
    var circulo9 = PocosNieve(300, -500, 15)
    var circulo10 = PocosNieve(350, -300, 15)
    var circulo11 = PocosNieve(400, -200, 15)
    var circulo12 = PocosNieve(500, -130, 15)
    var circulo13 = PocosNieve(650, -40, 15)
    var circulo14 = PocosNieve(750, -200, 15)
    var circulo15 = PocosNieve(950, -230, 15)
    var circulo16 = PocosNieve(1050, -200, 15)
    var circulo17 = PocosNieve(350, -50, 15)
    var circulo18 = PocosNieve(400, -300, 15)
    var circulo19 = PocosNieve(500, -40, 15)
    var circulo20 = PocosNieve(650, -400, 15)
    var circulo21 = PocosNieve(750, -500, 15)
    var circulo22 = PocosNieve(950, -630, 15)
    var circulo23 = PocosNieve(1050, -400, 15)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var paint = Paint()
        canvas.drawColor(Color.BLUE)
        //SOL
        paint.color=Color.YELLOW
        canvas.drawCircle(700F,100F,100F,paint)
       //PASTO
        paint.color=Color.GREEN
        canvas.drawRect(0F,1000F,width.toFloat(),height.toFloat(),paint)
       //CASA
        paint.color=Color.GRAY
        canvas.drawRect(400F,900F,900F,1300F,paint)
        //VENTANA
        paint.color=Color.CYAN
        canvas.drawCircle(550F,1100F,50F,paint)
        //PUERTA
        paint.color=Color.BLACK
        canvas.drawRect(700F,1150F,850F,1300F,paint)
        //TRONCO
        paint.color=Color.DKGRAY
        canvas.drawRect(100F,1000F,180F,1300F,paint)
        //HOJAS
        paint.color=Color.GREEN
        canvas.drawCircle(140F,950F,100F,paint)
        canvas.drawCircle(140F,850F,100F,paint)
        //TECHO
        paint.strokeWidth = 4f
        paint.color=Color.MAGENTA
        paint.style = Paint.Style.FILL_AND_STROKE
        paint.isAntiAlias = true
        val centro = Point(650, 700)
        val esquinaIzquierda = Point(400, 900)
        val esquinaDerecha = Point(900, 900)
        val path = Path()
        path.fillType = FillType.EVEN_ODD
        path.moveTo(centro.x.toFloat(), centro.y.toFloat())
        path.lineTo(esquinaIzquierda.x.toFloat(), esquinaIzquierda.y.toFloat())
        path.lineTo(esquinaDerecha.x.toFloat(), esquinaDerecha.y.toFloat())
        path.lineTo(centro.x.toFloat(), centro.y.toFloat())
        path.close()
        canvas.drawPath(path, paint)
        paint.color=Color.rgb(204, 204, 204)
        canvas.drawCircle(200F,350F,80F,paint)
        canvas.drawCircle(300F,350F,80F,paint)
        canvas.drawCircle(400F,350F,80F,paint)
        canvas.drawCircle(300F,270F,80F,paint)

        circulo0.pintar(canvas, paint)
        circulo1.pintar(canvas, paint)
        circulo2.pintar(canvas, paint)
        circulo3.pintar(canvas, paint)
        circulo4.pintar(canvas, paint)
        circulo5.pintar(canvas, paint)
        circulo6.pintar(canvas, paint)
        circulo7.pintar(canvas, paint)
        circulo8.pintar(canvas, paint)
        circulo9.pintar(canvas, paint)
        circulo10.pintar(canvas, paint)
        circulo11.pintar(canvas, paint)
        circulo12.pintar(canvas, paint)
        circulo13.pintar(canvas, paint)
        circulo14.pintar(canvas, paint)
        circulo15.pintar(canvas, paint)
        circulo16.pintar(canvas, paint)
        circulo17.pintar(canvas, paint)
        circulo18.pintar(canvas, paint)
        circulo19.pintar(canvas, paint)
        circulo20.pintar(canvas, paint)
        circulo21.pintar(canvas, paint)
        circulo22.pintar(canvas, paint)
        circulo23.pintar(canvas, paint)

    }

    fun animarCirculo() {
        circulo0.balanceo(width, height)
        circulo1.balanceo(width, height)
        circulo2.balanceo(width, height)
        circulo3.balanceo(width, height)
        circulo4.balanceo(width, height)
        circulo5.balanceo(width, height)
        circulo6.balanceo(width, height)
        circulo7.balanceo(width, height)
        circulo8.balanceo(width, height)
        circulo9.balanceo(width, height)
        circulo10.balanceo(width, height)
        circulo11.balanceo(width, height)
        circulo12.balanceo(width, height)
        circulo13.balanceo(width, height)
        circulo14.balanceo(width, height)
        circulo15.balanceo(width, height)
        circulo16.balanceo(width, height)
        circulo17.balanceo(width, height)
        circulo18.balanceo(width, height)
        circulo19.balanceo(width, height)
        circulo20.balanceo(width, height)
        circulo21.balanceo(width, height)
        circulo22.balanceo(width, height)
        circulo23.balanceo(width, height)
        invalidate()
    }
}